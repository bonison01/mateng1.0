# Mateng Marketing

# Environment Variables

### Database connection variables
POSTGRES_URL="" </br>
POSTGRES_PRISMA_URL="" </br>
POSTGRES_URL_NO_SSL="" </br>
POSTGRES_URL_NON_POOLING="" </br>
POSTGRES_USER="" </br>
POSTGRES_HOST="" </br>
POSTGRES_PASSWORD="" </br>
POSTGRES_DATABASE="" </br>

### Contacts and links
WHATSAPP_NUMBER="" </br>
PHONE_NUMBER="" </br>
CONTACT_EMAIL="" </br>
INSTAGRAM_PAGE="" </br>
FACEBOOK_PAGE="" </br>
YOUTUBE_CHANNEL="" </br>
LINKEDIN_PAGE="" </br>

### passkey for subscribers page
SUBSCRIBERS_PASSKEY = ""
