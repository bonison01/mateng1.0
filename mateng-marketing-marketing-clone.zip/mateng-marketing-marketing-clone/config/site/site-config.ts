export const siteConfig = {
  name: "Mateng",
  description: "Get your needs at your convenience.",
};
